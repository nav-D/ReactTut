import React, { Component } from "react";
import { Card, CardImg, CardImgOverlay,CardBody, CardText, CardTitle } from "reactstrap";
import DishDetail from "./DishdetailComponent";

class Menu extends Component {
  constructor(props) {
    super(props);

    this.state = {
        selectedDish: null,
        comments: null
    };
  }
  onDishSelect(dish){
      this.setState({selectedDish: dish, comments: dish.comments});
  }

  render() {
    const menu = this.props.dishes.map((dish) => {
        return (
            <div key={dish.id} className="col-12 col-md-5 m-1">
                <Card onClick={()=> this.onDishSelect(dish)}>
                    <CardImg width="100%" src={dish.image} alt={dish.name}/>  
                    <CardImgOverlay>
                        <CardTitle><h4>{dish.name}</h4></CardTitle>
                    </CardImgOverlay>
                </Card>
            </div> 
        );
    });

    return (
      <div className="container">
        <div className="row">
            {menu}
        </div>
        <div className="row">
            <div className="col-12 col-sm-5 m-1">
              <DishDetail selectedDish = {this.state.selectedDish} />
            </div>
            <div className="col-12 col-sm-5 m-1">
              <DishDetail comments = {this.state.comments} />
            </div>
        </div>

      </div>
    );
  }
}

export default Menu;
